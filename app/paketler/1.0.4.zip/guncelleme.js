/* App only: content updates without a store release.
   On launch and whenever the app comes back to the foreground, reads son.json from GitHub Pages.
   If it names a newer content version, the zip is downloaded in the background and set as the
   next bundle; it takes over the next time the app goes to the background and returns.
   The running bundle's version is window.ICERIK_SURUMU, written into index.html by build-app.py.
   Publish a new version with: python3 yayinla.py */
(function () {
  const SON = 'https://said-bay.github.io/hakikati-bul/app/son.json';
  const cap = window.Capacitor;
  if (!cap || !cap.isNativePlatform || !cap.isNativePlatform()) return;
  const U = cap.registerPlugin ? cap.registerPlugin('CapacitorUpdater') : cap.Plugins && cap.Plugins.CapacitorUpdater;
  if (!U) return;
  const mine = window.ICERIK_SURUMU || '0.0.0';
  const newer = (a, b) => {
    const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
    for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
    return false;
  };

  // tell the plugin this bundle started fine (otherwise it rolls back), then drop older downloads
  U.notifyAppReady().then(async () => {
    const cur = await U.current(), { bundles } = await U.list();
    for (const b of bundles) {
      if (b.id !== cur.bundle.id && b.status === 'success' && !newer(b.version, mine)) await U.delete({ id: b.id }).catch(() => {});
    }
  }).catch(() => {});

  let busy = false;
  async function check() {
    if (busy || !navigator.onLine) return;
    busy = true;
    try {
      const r = await fetch(SON + '?t=' + Date.now(), { cache: 'no-store' });
      if (!r.ok) return;
      const s = await r.json();
      if (!s.version || !s.url || !newer(s.version, mine)) return;
      const cur = await U.current();
      if (s.minNative && newer(s.minNative, cur.native)) return;   // needs a newer store build first
      const { bundles } = await U.list();
      let b = bundles.find(x => x.version === s.version && x.status === 'success');
      if (!b) b = await U.download({ url: s.url, version: s.version, checksum: s.checksum });
      await U.next({ id: b.id });
    } catch (e) {
      /* offline or server hiccup: keep the current content and try again next time */
    } finally {
      busy = false;
    }
  }
  check();
  document.addEventListener('visibilitychange', () => { if (!document.hidden) check(); });
})();
